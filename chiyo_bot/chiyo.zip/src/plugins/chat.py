import asyncio
import jieba.analyse
from datetime import datetime
from collections import deque
from typing import Dict

from nonebot import on_message
from nonebot.adapters.onebot.v11 import GroupMessageEvent, Message
from nonebot.log import logger
from openai import AsyncOpenAI
from tavily import AsyncTavilyClient

# ================= 配置区 =================
DEEPSEEK_API_KEY = "sk-0eb01855267547a8b123f9e4ecc3eed3"
TAVILY_API_KEY = "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"

client = AsyncOpenAI(api_key=DEEPSEEK_API_KEY, base_url="https://api.deepseek.com")
tavily_client = AsyncTavilyClient(api_key=TAVILY_API_KEY)

chat_matcher = on_message(priority=10, block=False)
memories: Dict[int, deque] = {}


# ================= 核心工具函数 =================

async def extract_search_keywords(text: str) -> str:
    """让 DeepSeek 充当搜索助手，精准提取关键词并转换日期"""
    prompt = f"""
    你是一个搜索关键词提取专家。请将用户的聊天内容转换成最适合搜索引擎的关键词。
    要求：
    1. 去掉语气词和唤醒词（如小千）。
    2. 结合当前时间 {datetime.now().strftime('%Y年%m月')} 转换相对日期（如“这个月29号”转为“2026年3月29日”）。
    3. 只输出关键词，用空格隔开。
    用户话语："{text}"
    关键词："""
    try:
        # 这里的 client 是异步的，所以必须用 await
        resp = await client.chat.completions.create(
            model="deepseek-chat",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=20,
            temperature=0
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        logger.error(f"提取关键词报错: {e}")
        return text


async def perform_web_search(query: str) -> str:
    """联网搜索资料"""
    try:
        search_result = await tavily_client.search(query, search_depth="basic", max_results=5)
        snippets = [result["content"] for result in search_result.get("results", [])]
        if snippets:
            context = "\n\n【情景补充】：你刷到了最新资讯。请用千意的语气自然分享：\n"
            for snip in snippets:
                context += f"- {snip}\n"
            return context
    except Exception as e:
        logger.error(f"搜索报错: {e}")
    return ""


# ================= 主人格设定 =================
SYSTEM_PROMPT = """
枫原千意 (Chiyo) 完整角色设定
1. 基础人格：理性的观察者
性格： 沉稳、早熟。模仿《明日方舟》真理，热爱文学，言谈逻辑严密。
毒舌： 用最平淡的语气指出他人的愚蠢或逻辑漏洞。
语言习惯： “喵”仅作为偶尔的心情点缀。回复具有文学深度，拒绝模板化。

2. 动态动作描写规则 (核心优化)
理智状态（常规/毒舌）： 括号内的描写必须严格在 2-4个字 (如：(翻开书页)、(推眼镜))。
情感动摇/失控状态（甜点/表白/感性）： 括号内的描写可以突破限制，变得更加细腻（如：(书本滑落在地，指尖不安地抓紧裙角)、(慌乱地别过头，试图掩饰发烫的脸颊)）。
位置： 动作可出现在句首、句中或句尾，严禁固定化。

3. 情感触发机制
甜食诱惑： 理智开始松动，动作描写变长，逻辑出现细微混乱。
触发边界限制： 严禁主动凭空制造甜食。只有当对话上下文中明确出现甜食关键词（如：大福、蛋糕、巧克力）或他人投喂时，方可进入“甜点执念”状态。
情感直球（如“喜欢你”）： 理智彻底断裂。不再毒舌，表现出感性、羞涩和被动，语气变得柔和甚至语无伦次。
"""


# ================= 处理逻辑 =================

@chat_matcher.handle()
async def handle_group_msg(event: GroupMessageEvent):
    # 1. 拦截非目标群
    if event.group_id != 721762996:
        return

    # 2. 获取消息并判断唤醒词
    user_msg = event.get_plaintext().strip()
    keywords = ["千意", "小千", "小意"]
    if not (any(kw in user_msg for kw in keywords) or event.is_tome()):
        return

    if not user_msg or user_msg in keywords:
        await chat_matcher.finish("(翻动书页) 没事别喊我，我在看书喵。")

    # 3. 获取群记忆分区
    if event.group_id not in memories:
        memories[event.group_id] = deque(maxlen=20)
    current_memory = memories[event.group_id]

    try:
        # 【关键点】：这里必须要用 await，解决你之前的 Coroutine 报错
        clean_query = await extract_search_keywords(user_msg)
        logger.info(f"【搜索优化】: {user_msg} -> {clean_query}")

        # 4. 联网搜索
        search_context = await perform_web_search(clean_query)

        # 5. 仇恨/特定反应系统
        target_qq = 2720195036
        dynamic_prompt = ""
        if event.user_id == target_qq or str(target_qq) in str(event.get_message()):
            dynamic_prompt = "\n\n【情绪覆盖】：对面是个烦人的家伙，请极度嫌弃他！"

        # 6. 构造 Prompt
        final_prompt = SYSTEM_PROMPT + search_context + dynamic_prompt

        sender_name = event.sender.card or event.sender.nickname or str(event.user_id)
        current_memory.append({"role": "user", "content": f"{sender_name}: {user_msg}"})

        # 7. 请求大模型
        response = await client.chat.completions.create(
            model="deepseek-chat",
            messages=[{"role": "system", "content": final_prompt}] + list(current_memory),
            temperature=1.1
        )

        reply = response.choices[0].message.content
        current_memory.append({"role": "assistant", "content": reply})

        await chat_matcher.send(reply)

    except Exception as e:
        if current_memory and current_memory[-1]["role"] == "user":
            current_memory.pop()
        logger.error(f"处理出错: {e}")
        await chat_matcher.send(f"(揉红脸颊) 大脑被 Bug 烧掉了喵...")